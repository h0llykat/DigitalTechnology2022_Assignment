import math

with open('instructions.txt') as file_object:
  instructions = file_object.read()
  print(instructions)

def calc(x, y, z):
    return {
        '+': lambda: y + z,
        '-': lambda: y - z,
        '*': lambda: y * z,
        '/': lambda: y / z,
        'L': lambda: math.sqrt((y ** 2) + (z ** 2)),
        '^': lambda: y ** z
    }.get(x, lambda: 'Not a valid operation')()

i = True
while i == True:
  operation, var1, var2 = input("Enter equation: ").split()
  var1 = float(var1)
  var2 = float(var2)
  print(f"Answer: {calc(operation, var1, var2)}\n")
  i = True